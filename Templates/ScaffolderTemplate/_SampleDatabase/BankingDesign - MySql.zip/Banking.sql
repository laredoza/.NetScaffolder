CREATE DATABASE  IF NOT EXISTS `bankingdesign` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `bankingdesign`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: bankingdesign
-- ------------------------------------------------------
-- Server version	5.7.22-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bankaccount`
--

DROP TABLE IF EXISTS `bankaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bankaccount` (
  `BankAccountId` int(11) NOT NULL,
  `BankAccountNumber` varchar(10) NOT NULL,
  `Balance` decimal(19,4) NOT NULL,
  `CustomerId` int(11) DEFAULT NULL,
  `Locked` bit(1) NOT NULL,
  PRIMARY KEY (`BankAccountId`),
  UNIQUE KEY `UQ__BankAcco__4FC8E4A0C45281C8` (`BankAccountId`),
  KEY `IX_CustomerId` (`CustomerId`),
  CONSTRAINT `FK_BankAccount_Customer_CustomerId` FOREIGN KEY (`CustomerId`) REFERENCES `customer` (`CustomerId`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bankaccount`
--

LOCK TABLES `bankaccount` WRITE;
/*!40000 ALTER TABLE `bankaccount` DISABLE KEYS */;
/*!40000 ALTER TABLE `bankaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banktransfers`
--

DROP TABLE IF EXISTS `banktransfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banktransfers` (
  `BankTransferId` int(11) NOT NULL,
  `FromBankAccountId` int(11) NOT NULL,
  `ToBankAccountId` int(11) NOT NULL,
  `Amount` decimal(18,2) NOT NULL,
  `TransferDate` datetime(6) NOT NULL,
  PRIMARY KEY (`BankTransferId`),
  UNIQUE KEY `UQ__BankTran__2E82727AB11DB584` (`BankTransferId`),
  KEY `IX_ToBankAccountId` (`ToBankAccountId`),
  CONSTRAINT `FK_BankTransfers_BankAccount_ToBankAccountId` FOREIGN KEY (`ToBankAccountId`) REFERENCES `bankaccount` (`BankAccountId`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banktransfers`
--

LOCK TABLES `banktransfers` WRITE;
/*!40000 ALTER TABLE `banktransfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `banktransfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `ProductId` int(11) NOT NULL,
  `Publisher` varchar(200) NOT NULL,
  PRIMARY KEY (`ProductId`),
  KEY `IX_ProductId` (`ProductId`),
  CONSTRAINT `FK_Book_Product_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `product` (`ProductId`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `CountryId` int(11) NOT NULL,
  `CountryName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CountryId`),
  UNIQUE KEY `UQ__Country__10D1609E8CC26505` (`CountryId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `CustomerId` int(11) NOT NULL,
  `CustomerCode` varchar(5) NOT NULL,
  `CompanyName` varchar(50) NOT NULL,
  `ContactName` varchar(50) DEFAULT NULL,
  `ContactTitle` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `City` varchar(20) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  `Telephone` varchar(50) DEFAULT NULL,
  `Fax` varchar(50) DEFAULT NULL,
  `CountryId` int(11) DEFAULT NULL,
  `Photo` varchar(255) DEFAULT NULL,
  `IsEnabled` bit(1) NOT NULL,
  PRIMARY KEY (`CustomerId`),
  UNIQUE KEY `UQ__Customer__A4AE64D98B60CE6B` (`CustomerId`),
  KEY `IX_CountryId` (`CountryId`),
  CONSTRAINT `FK_Customer_Country_CountryId` FOREIGN KEY (`CountryId`) REFERENCES `country` (`CountryId`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `OrderId` int(11) NOT NULL,
  `CustomerId` int(11) DEFAULT NULL,
  `OrderDate` datetime(6) DEFAULT NULL,
  `DeliveryDate` datetime(6) DEFAULT NULL,
  `ShippingName` varchar(50) DEFAULT NULL,
  `ShippingAddress` varchar(50) DEFAULT NULL,
  `ShippingCity` varchar(50) DEFAULT NULL,
  `ShippingZip` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`OrderId`),
  UNIQUE KEY `UQ__Order__C3905BCE3C614174` (`OrderId`),
  KEY `IX_CustomerId` (`CustomerId`),
  CONSTRAINT `FK_Order_Customer_CustomerId` FOREIGN KEY (`CustomerId`) REFERENCES `customer` (`CustomerId`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderdetails`
--

DROP TABLE IF EXISTS `orderdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderdetails` (
  `OrderDetailsId` int(11) NOT NULL,
  `OrderId` int(11) NOT NULL,
  `ProductId` int(11) NOT NULL,
  `UnitPrice` decimal(19,4) DEFAULT NULL,
  `Amount` smallint(6) DEFAULT NULL,
  `Discount` float DEFAULT NULL,
  PRIMARY KEY (`OrderDetailsId`),
  UNIQUE KEY `UQ__OrderDet__9DD74DBC8AA17DA0` (`OrderDetailsId`),
  KEY `IX_OrderId` (`OrderId`),
  KEY `IX_ProductId` (`ProductId`),
  CONSTRAINT `FK_OrderDetails_Order_OrderId` FOREIGN KEY (`OrderId`) REFERENCES `order` (`OrderId`) ON DELETE NO ACTION,
  CONSTRAINT `FK_OrderDetails_Product_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `product` (`ProductId`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetails`
--

LOCK TABLES `orderdetails` WRITE;
/*!40000 ALTER TABLE `orderdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `ProductId` int(11) NOT NULL,
  `ProductDescription` varchar(100) DEFAULT NULL,
  `UnitPrice` decimal(19,4) DEFAULT NULL,
  `AmountInStock` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`ProductId`),
  UNIQUE KEY `UQ__Product__B40CC6CC5F2A0195` (`ProductId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `software` (
  `ProductId` int(11) NOT NULL,
  `LicenseCode` varchar(200) NOT NULL,
  PRIMARY KEY (`ProductId`),
  KEY `IX_ProductId` (`ProductId`),
  CONSTRAINT `FK_Software_Product_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `product` (`ProductId`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `software`
--

LOCK TABLES `software` WRITE;
/*!40000 ALTER TABLE `software` DISABLE KEYS */;
/*!40000 ALTER TABLE `software` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-01 18:55:29
