Required:
T4Toolbox

Generate Code:
1. Find "RunGenerator.tt" in the solution 
2 .Right click on the file and run the custom tool to generate the classes.

