﻿namespace DotNetScaffolder.Domain.Infrastructure.Web.Core.Security
{
    public static class MyClaimTypes
    {
        public const string Permission = "Permission";
        public const string Role = "Role";
        public const string Generic = "Role";
    }
}
