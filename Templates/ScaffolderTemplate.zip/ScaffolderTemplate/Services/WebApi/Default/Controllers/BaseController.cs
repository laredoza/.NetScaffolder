﻿using Microsoft.AspNetCore.Mvc;

namespace DotNetScaffolder.Domain.Services.WebApi.Default.Controllers
{
    public class BaseController : ControllerBase
    {
    }
}
