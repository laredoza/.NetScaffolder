﻿using System;

namespace DotNetScaffolder.Domain.Migrations.EFCore.Postgres
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
