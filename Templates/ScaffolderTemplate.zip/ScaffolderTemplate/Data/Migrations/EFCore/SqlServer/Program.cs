﻿using System;

namespace DotNetScaffolder.Domain.Migrations.EFCore.SqlServer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
